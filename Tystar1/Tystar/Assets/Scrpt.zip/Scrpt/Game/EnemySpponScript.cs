using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class EnemySpponScript : MonoBehaviour
{
    [SerializeField] List<GameObject> enemyList = new List<GameObject>();
    [SerializeField] Sprite[] Alphabet;
    [SerializeField] Transform[] spawnPoints;
    [SerializeField] int maxEnemies = 100;

    [SerializeField] float timeBetweenEnemies = 0.5f;
    [SerializeField] float timeBetweenWaves = 10f;


    [SerializeField] int ginoMax = 10;
    [SerializeField] int totalPhaes = 3;
    public BossScript boss;


    private List<int> KillsThisFrame = new List<int>();
    private int totalGinoCount = 0;
    private int totalGinoMax = 0;
    private int totalScore = 0;
    private int stopGinoCount = 11;
    private bool canSpawn = true;
    public int score = 0;
    public UItextScript UItext;

    //�X�|�[���p�^�[��
    private List<int[]> spawnPatterns = new List<int[]>()
    {
        new int[]{0,1,2,3},
        new int[]{3,2,1,0},
        new int[]{0,2,1,3},
        new int[]{3,1,2,0},
        new int[]{0,3,1,2},
        new int[]{2,1,3,0},
    };
    public enum GinoCount
    {
        easy,
        normal,
        hard
    }
    public GinoCount stopcount =GinoCount.easy;

    public void selctcount()
    {
        //�I�񂾃��[�h�ɂ���ă{�X��ڍs�̐���ύX
        switch (stopcount)
        {
                case GinoCount.easy:stopGinoCount=11; break;
                case GinoCount.normal:stopGinoCount=22;break;
                case GinoCount.hard:stopGinoCount=30;break;

        }

    }


    void Start()
    {
        selctcount();

        if (staticScript.ReturnedFromBoss)
        {
            staticScript.ReturnedFromBoss = false;
            
            //�{�X��I������琔�l�߂��̂ƃ{�X��ڍs����܂ł̐��l+2
            score = staticScript.SaveScore;
            totalGinoCount = staticScript.SaveKillCount;
            stopGinoCount = staticScript.SaveMaxGino;
            UItext.SetCount(score, totalGinoCount);
            stopGinoCount += 2;

            StartCoroutine(SpawnLoop());
        }
        else
        {
           //�X�^�[�g���Ȃ琔�l0��
           // staticScript.BossHP = 1500;
            staticScript.SaveKillCount = totalGinoCount;
            staticScript.SaveMaxGino = stopGinoCount;
            staticScript.SaveScore = score;
            staticScript.SavePlayerHP = 6;

            // BossHp.HPMAX(1500);
            selctcount();
            score = 0;
            totalGinoCount = 0;
            StartCoroutine(SpawnLoop());
        }
    }



    void Update()
    {
        // 1�t���[�����ɕ������j���������瓯�����j����
        if (KillsThisFrame.Count > 0)
        {
            if (KillsThisFrame.Count >= 4)
                SCORE(1.5f, 4);
            else if (KillsThisFrame.Count == 3)
                SCORE(1.25f, 3);
            else if (KillsThisFrame.Count == 2)
                SCORE(1.1f, 2);
            else
                SCORE(1f, 1);
        }
        //�t���[���I�����Ƀ��Z�b�g
        KillsThisFrame.Clear();
    }


    //���������܂ł̎g���Ă���
    //private IEnumerator SpawnLoop()
    //{
    //    canSpawn = true;

    //    while (canSpawn)
    //    {
    //        SpawnOneEnemy();
    //        yield return new WaitForSeconds(timeBetweenEnemies);
    //    }
    //}
    //private void SpawnOneEnemy()
    //{
    //    if (enemyList.Count == 0 || spawnPoints.Length == 0) return;

    //    int spawnIndex = Random.Range(0, spawnPatterns.Count);
    //    GameObject enemyPrefab = enemyList[Random.Range(0, enemyList.Count)];

    //    int index = Random.Range(0, Alphabet.Length);
    //    char letter = (char)('A' + index);

    //    GameObject enemy = Instantiate(
    //        enemyPrefab,
    //        spawnPoints[spawnIndex].position,
    //        Quaternion.identity
    //    );

    //    var script = enemy.GetComponent<tekiScript>();
    //    if (script != null)
    //    {
    //        script.AppEnemy = this;
    //        script.assignedChar = letter;
    //        script.assignedKey =
    //            (KeyCode)System.Enum.Parse(typeof(KeyCode), letter.ToString());
    //    }

    //    Image img = enemy.GetComponentInChildren<Image>();
    //    if (img != null)
    //    {
    //        img.sprite = Alphabet[index];
    //    }
    //}
    //�����܂ł������Ă����

    //private IEnumerator SpawnEnemiesWithDelay()
    //{


    //    //�p�^�[�������_��
    //    int[] chosenPattern = spawnPatterns[Random.Range(0, spawnPatterns.Count)];
    //    //�I�΂ꂽ���ԂɃX�|�[��
    //    foreach (int i in chosenPattern)
    //    {
    //        GameObject enemyPrefab = enemyList[Random.Range(0, enemyList.Count)];
    //        if (totalSpawned >= maxEnemies) yield break;
    //        if (i >= spawnPoints.Length) continue;

    //        //�G�Ƀ����_���ɕ����t�^
    //        int index = Random.Range(0, Alphabet.Length);
    //        char letter = (char)('A' + index);

    //        GameObject enemy = Instantiate(enemyPrefab, spawnPoints[i].position, Quaternion.identity);
    //        var script = enemy.GetComponent<tekiScript>();

    //        if (script != null)
    //        {
    //            script.AppEnemy = this;
    //            script.assignedChar = letter;
    //            script.assignedKey = (KeyCode)System.Enum.Parse(typeof(KeyCode), letter.ToString());
    //        }

    //        Image img = enemy.GetComponentInChildren<Image>();
    //        if (img != null && index < Alphabet.Length)
    //        {
    //            img.sprite = Alphabet[index];
    //        }

    //        //totalSpawned++;
    //        //yield return new WaitForSeconds(timeBetweenEnemies);
    //    }
    //}

    private IEnumerator SpawnLoop()
    {
        canSpawn = true;

        while (canSpawn)
        {
            // --- 1��I�� ---
            int[] wave = spawnPatterns[Random.Range(0, spawnPatterns.Count)];

            // --- ��̒���4�̂����Ԃɏo�� ---
            foreach (int spawnIndex in wave)
            {
                SpawnOneEnemy(spawnIndex);
                yield return new WaitForSeconds(timeBetweenEnemies);
            }

            // --- ���̉�܂ő҂� ---
            yield return new WaitForSeconds(timeBetweenWaves);
        }
    }
    private void SpawnOneEnemy(int spawnIndex)
    {
        if (enemyList.Count == 0 || spawnPoints.Length == 0) return;
        if (spawnIndex < 0 || spawnIndex >= spawnPoints.Length) return;

        //�G�������_���ŏo��������
        GameObject enemyPrefab = enemyList[Random.Range(0, enemyList.Count)];

        //�o��������G�Ƀ����_���A���t�@�x�b�g�t�^
        int index = Random.Range(0, Alphabet.Length);
        //�Ή����镶��
        char letter = (char)('A' + index);

        //�G���X�|�[��������
        GameObject enemy = Instantiate(
            enemyPrefab,
            spawnPoints[spawnIndex].position,
            Quaternion.identity
        );

        var script = enemy.GetComponent<tekiScript>();
        if (script != null)
        {
            script.AppEnemy = this;
            script.assignedChar = letter;
            script.assignedKey =
                (KeyCode)System.Enum.Parse(typeof(KeyCode), letter.ToString());
        }

        //�A���t�@�x�b�g��UI(Image)��\��������
        Image img = enemy.GetComponentInChildren<Image>();
        if (img != null)
        {
            img.sprite = Alphabet[index];
        }
    }



    //�G�����񂾂�Ă΂��
    public void ReportEnemyDefeated(int baseScore)
    {
        totalGinoMax++;
        totalGinoCount++;
       // totalDefeated++;
        KillsThisFrame.Add(baseScore);

        if (totalGinoMax >= stopGinoCount)
        {
            Debug.Log($"�K�萔���B: {totalGinoMax}/{stopGinoCount}");
            canSpawn = false;
            StartCoroutine(WaitAndGoBoss());
        }
    }
    private IEnumerator WaitAndGoBoss()
    {
        //�V�[���ړ�����O�ɐ��l�̕ۑ�
        yield return new WaitForSeconds(0.1f);
        staticScript.LastSceneName = SceneManager.GetActiveScene().name;
        staticScript.SaveScore = totalScore;
        staticScript.SavePlayerHP = GameObject.FindWithTag("Player")
            ?.GetComponent<Playerscrpt>()?.GetCurrentHP() ?? 0;
        staticScript.SaveKillCount = totalGinoCount;
        staticScript.SaveMaxGino = stopGinoCount;
        staticScript.ReturnedFromBoss = true;
        

        staticScript.IsGoingToBoss = true;  // �� �ǉ��i�{�X��O�j

        Debug.Log("VideoTransitionScene�Ɉړ����܂�");
        UnityEngine.SceneManagement.SceneManager.LoadScene("VideoTransitionScene");
    }
    public void SCORE(float Multiple, int Enemy)
    {
        int total = 0;
        foreach (int s in KillsThisFrame)
            total += s;
        total = Mathf.RoundToInt(total * Multiple);
        score += total;
        UItext.Count(score, Enemy);
        totalScore += score;
    }

}