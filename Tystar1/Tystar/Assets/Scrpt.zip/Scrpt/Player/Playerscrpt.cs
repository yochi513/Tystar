using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Video;

public class Playerscrpt : MonoBehaviour
{
    private int currentHP = 6;
    public int PlayerHP = 3;
    public bool isInvincible = false;
    public float invincibleTime = 1.5f;
 

    [SerializeField] Canvas Gameover;
    [SerializeField] Canvas MainCanvas;

    void Start()
    {
        Gameover.gameObject.SetActive(false);
        MainCanvas.gameObject.SetActive(true);
    }

    void Update()
    {


    }


    public int GetCurrentHP()
    {
        return currentHP;
    }
    public void SetHP(int hp)
    {
        currentHP = hp;
    }
    public void TakeDamage(int damage)
    {
        if (isInvincible) return;

        PlayerHP -= damage;

        StartCoroutine(InvincibleCoroutine());
        if (PlayerHP <= 0)
        {
            GameOVER();
        }
    }

    
    IEnumerator InvincibleCoroutine()
    {
        //isInvincible = true; // ���GON
        yield return new WaitForSeconds(invincibleTime); // ���߂����ԑ҂�
        //isInvincible = false; // ���GOFF
    }
    
    public void GameOVER()
    {
        //Debug.Log("�v���C���[���|�ꂽ");
        Gameover.gameObject.SetActive(true);
       
        MainCanvas.gameObject.SetActive(false);
    }

}