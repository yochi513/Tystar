using UnityEngine;
using UnityEngine.UI;

public class BossGaugeScript : MonoBehaviour
{
    [SerializeField] Image gaugeImage;
    [SerializeField] int MaxCharge = 50;

    public int currentCharge = 0;
    public KeyCode assignedKey;   // BossWaveScript ����ݒ肷��
    public System.Action OnGaugeMax;  // �Q�[�WMAX���ɒʒm

    void Update()
    {
        if (Input.GetKey(assignedKey))
        {
            Tystar(+1);
        }
        else
        {
            Tystar(-1);
        }
    }

    public void Tystar(int amount)
    {
        if (amount == 1)
            currentCharge++;
        else
            currentCharge--;

        currentCharge = Mathf.Clamp(currentCharge, 0, MaxCharge);
        UpdateGauge();

        // MAX�ɂȂ����� BossWaveScript �ɒm�点��
        if (currentCharge >= MaxCharge)
        {
            OnGaugeMax?.Invoke();
        }
    }

    private void UpdateGauge()
    {
        if (gaugeImage != null)
        {
            gaugeImage.fillAmount = (float)currentCharge / MaxCharge;
        }
    }
}
