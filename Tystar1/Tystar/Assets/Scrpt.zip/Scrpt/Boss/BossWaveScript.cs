using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.UI;

public class BossWaveScript : MonoBehaviour
{
    [SerializeField] GameObject ballPrefab;
    [SerializeField] Transform supar;
    [SerializeField] Transform player;
    [SerializeField] Sprite[] Alphabet;
    [SerializeField] GameObject Entra;

    public BallCHScrpt BallCH;
    public PlayerStateScript playerState;
    public BallScript Ball;
   

    int phase = 0;
    GameObject ball;
    char currentLetter;
    public KeyCode currentKey;
    Sprite currentSprite;

    private bool isWaitingForReflect = false;
    private bool bossPhaseStarted = false; // �{�X�t�F�[�Y�J�n�t���O



    void Start()
    {
        StartNextPhase();
       Entra.SetActive(false);  
    }

    void StartNextPhase()
    {
        if (phase >= 3)
        {
            Entra.gameObject.SetActive(true);
            staticScript.BossCount++;
            Debug.Log("Boss�t�F�[�Y�˓���" + staticScript.BossCount);
            if (!bossPhaseStarted)
            {
                bossPhaseStarted = true;
                playerState.BossAttack();
                Debug.Log("�{�X�U���t�F�[�Y�J�n�I�X�e�[�g: " + PlayerStateScript.CurrentState);
                Debug.Log("���݂̃`���[�W��: " + staticScript.SaveCh);
            }
            return;
        }

        int index = Random.Range(0, Alphabet.Length);
        currentLetter = (char)('A' + index);
        currentKey = (KeyCode)System.Enum.Parse(typeof(KeyCode), currentLetter.ToString());
        currentSprite = Alphabet[index];

        ball = Instantiate(ballPrefab, supar.position, Quaternion.identity);
        ball.GetComponent<BallScript>().Init(currentLetter, currentKey, player, supar, currentSprite);

        isWaitingForReflect = true;
        Debug.Log($"�t�F�[�Y{phase + 1}: �L�[ '{currentLetter}' �������ă{�[���𒵂˕Ԃ��Ă�������");
    }

    void Update()
    {
        // �{�X�t�F�[�Y�Ɉڍs������L�[���͂��󂯕t���Ȃ�
        if (bossPhaseStarted) return;

        if (isWaitingForReflect && Input.GetKeyDown(currentKey))
        {
            ball.GetComponent<BallScript>().Reflect();

            Animator suparAnimator = supar.GetComponent<Animator>();
            if (suparAnimator != null)
            {
                suparAnimator.SetTrigger("Attack");
            }

            isWaitingForReflect = false;
            phase++;

            Invoke(nameof(StartNextPhase), 1f);
        }
    }
}