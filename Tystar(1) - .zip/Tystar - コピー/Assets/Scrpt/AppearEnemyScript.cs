using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class AppearEnemyScript : MonoBehaviour
{
    [SerializeField] GameObject[] enemys;
    [SerializeField] int maxNumEnemys;
    private int numEnemys;

     void Start()
    {
        
    }

     void Update()
    {
        if(numEnemys>=maxNumEnemys)
        {
            return;
        }


    }
    void AppearEnemy()
    {
        var randomValue = Random.Range(0, enemys.Length);

        GameObject.Instantiate(enemys[randomValue], transform.position, Quaternion.Euler(0f, 0f, 0f));

        numEnemys++;
    }
}
