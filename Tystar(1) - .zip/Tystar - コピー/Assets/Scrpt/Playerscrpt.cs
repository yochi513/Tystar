using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playerscrpt : MonoBehaviour
{
    // �ړ����x�Ɖ�]���x��ݒ�
    public float moveSpeed = 5f;
    //public float rotationSpeed = 100f;

    void Update()
    {
        // �㉺�L�[�őO��Ɉړ�
�@�@�@if (Input.GetKey(KeyCode.UpArrow)|| (Input.GetKey(KeyCode.DownArrow)))
        {
            float move = Input.GetAxis("Vertical")* moveSpeed * Time.deltaTime;
            transform.Translate(0, 0, move);

        }
        // ���E�L�[�ŉ��ړ�
        if (Input.GetKey(KeyCode.RightArrow) || (Input.GetKey(KeyCode.LeftArrow)))
        {
            float move2 = Input.GetAxis("Horizontal") * moveSpeed * Time.deltaTime;
            transform.Translate(move2, 0, 0);

        }

    }
}