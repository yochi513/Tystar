using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using Unity.VisualScripting;

public class ChargeScript : MonoBehaviour
{

    [SerializeField] Image Char;
  private float MaxCharge = 500f;
    private float currentCharge = 0f;
    public enum Selection
    {
        Two=2,
        Three = 3,
        Four = 4,
        Five = 5

    }

    public Selection Chargetime = Selection.Three;
    public void select()
    {
        if (Chargetime == Selection.Two)
        {
            MaxCharge = 100f;
        }
        else if (Chargetime == Selection.Three)
        {
            MaxCharge = 150f;
        }
        else if (Chargetime == Selection.Four)
        {
            MaxCharge = 200f;
        }
        else if (Chargetime == Selection.Five)
        {
            MaxCharge = 250f;
        }

    }

    // �Q�[�W���Z�i�G����Ăяo�����j
    public void Tystar(int amount)
    {
        select();
        if (amount == 1) 
        {
            currentCharge ++; 
        }
        else
        {
            currentCharge--;
        }
        currentCharge = Mathf.Clamp(currentCharge, 0, MaxCharge);
        UpdateGauge();
    }
    public void Entar(GameObject target)
    {
        select();
        if (currentCharge >= MaxCharge && Input.GetKeyDown(KeyCode.Return))
        {
            Destroy(target);
            UpdateGauge();
        }
    }

    // UI�X�V
    private void UpdateGauge()
    {
        select();
        if (Char != null)
        {
            Char.fillAmount = currentCharge / MaxCharge;
        }
    }
}

//300f��6�b���炢
//250f��5�b���炢
//200f��4�b���炢
//150f��3�b���炢
