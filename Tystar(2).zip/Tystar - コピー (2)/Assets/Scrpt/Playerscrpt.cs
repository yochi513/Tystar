using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Playerscrpt : MonoBehaviour
{
    // �ړ����x�Ɖ�]���x��ݒ�
   // public float moveSpeed = 5f;
    //public float rotationSpeed = 100f;
    public int PlayerHP = 1;
    [SerializeField] Canvas Gameover;
     void Start()
    {
        Gameover.gameObject.SetActive(false);    
    }

    void Update()
    {
   //     // �㉺�L�[�őO��Ɉړ�
�@�@�@//if (Input.GetKey(KeyCode.UpArrow)|| (Input.GetKey(KeyCode.DownArrow)))
   //     {
   //         float move = Input.GetAxis("Vertical")* moveSpeed * Time.deltaTime;
   //         transform.Translate(0, 0, move);

   //     }
   //     // ���E�L�[�ŉ��ړ�
   //     if (Input.GetKey(KeyCode.RightArrow) || (Input.GetKey(KeyCode.LeftArrow)))
   //     {
   //         float move2 = Input.GetAxis("Horizontal") * moveSpeed * Time.deltaTime;
   //         transform.Translate(move2, 0, 0);

   //     }

    }
    public void TakeDamage(int damage)
    {
        PlayerHP -= damage;

        if (PlayerHP <= 0)
        {
            Debug.Log("�v���C���[���|�ꂽ");
            Gameover.gameObject.SetActive(true);
            // �Q�[���I�[�o�[�����Ȃ�
        }
    }
}