using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class tekiScript : MonoBehaviour
{
    private GameObject target;
    public float speed = 0.05f;

    public string word;
    public KeyCode assignedKey;
    public char assignedChar;
    public Color enemyColor;

    public ChargeScript charge;
    public AppearEnemyScript AppEnemy;

    private Renderer rend;
    private TextMeshPro textDisplay;

    void Start()
    {
        target = GameObject.Find("player");
        rend = GetComponent<Renderer>();
        rend.material.color = enemyColor;

        textDisplay = GetComponentInChildren<TextMeshPro>();
        if (textDisplay != null)
        {
            textDisplay.text = assignedKey.ToString();
        }
    }

    void Update()
    {
        transform.LookAt(target.transform);
        transform.position += transform.forward * speed;

        if (Input.GetKey(assignedKey))
        {
            charge.Tystar(+1);
            charge.EntarWithCallback(gameObject, AppEnemy); // �C���|�C���g�I
        }
        else
        {
            charge.Tystar(-1);
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("Player"))
        {
            // �v���C���[����PlayerHealth���擾
            Playerscrpt playerHealth = other.GetComponent<Playerscrpt>();
            if (playerHealth != null)
            {
                playerHealth.TakeDamage(1); // �G�̃_���[�W��
            }
        }
    }
}
